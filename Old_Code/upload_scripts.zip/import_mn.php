<pre>
<?php

// begin config
$filename = "MN06StPaul_mn.xls";
$expname = "MN06StPaul";
$capcode_col = 1;
$linename_col = 2;
$headingdate_col = 3;
$plantheight_col = 4;
$grainyield_col = 5;
// end config

require_once('reader.php');
$reader = & new Spreadsheet_Excel_Reader();
$reader->setOutputEncoding('CP1251');
$reader->read($filename);
$sheet = & $reader->sheets[0];

$conn = mysql_connect("lab.bcb.iastate.edu", "yhames04", "gdcb07");
mysql_select_db("sandbox_yhames04_dev");

for ($rowIndex = 2; $rowIndex <= count($sheet['cells']); $rowIndex++)
{
	$capcode = isset($sheet['cells'][$rowIndex][$capcode_col]) ?
				"'".$sheet['cells'][$rowIndex][$capcode_col]."'" :
				"NULL";
	$linename = $sheet['cells'][$rowIndex][$linename_col];
	$headingdate = $sheet['cells'][$rowIndex][$headingdate_col];
	$plantheight = $sheet['cells'][$rowIndex][$plantheight_col];
	$grainyield = $sheet['cells'][$rowIndex][$grainyield_col];
	
	$sql = "INSERT LOW_PRIORITY INTO tht_base (line_record_uid, experiment_uid, cap_code, created_on)
			VALUES (
				(SELECT line_record_uid FROM line_records WHERE line_record_name = '$linename' LIMIT 1),
				(SELECT experiment_uid FROM experiments WHERE experiment_name = '$expname' LIMIT 1),
				$capcode,
				NOW()
				);";
	mysql_query($sql) or die(mysql_error() . "\n\n$sql");
	
	$tht_base_uid = mysql_insert_id();
	
	$sql2 = "INSERT LOW_PRIORITY INTO phenotype_data (phenotype_uid, tht_base_uid, value, created_on)
				VALUES ('4','$tht_base_uid','$headingdate',NOW()),
				('2','$tht_base_uid','$plantheight',NOW()),
				('1','$tht_base_uid','$grainyield',NOW());";
	
	mysql_query($sql2) or die(mysql_error() . "\n\n$sql2");
}

echo "\n\nDone!";
