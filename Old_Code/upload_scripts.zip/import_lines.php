<pre>
<?php

// begin Config
$filename = "MN06StPaul_mn.xls";
$linename_col = 2;
// end Config

require_once('reader.php');
$reader = & new Spreadsheet_Excel_Reader();
$reader->setOutputEncoding('CP1251');
$reader->read($filename);
$sheet = & $reader->sheets[0];

$conn = mysql_connect("lab.bcb.iastate.edu", "yhames04", "gdcb07");
mysql_select_db("sandbox_yhames04_dev");

$sql_copy = $sql = "INSERT LOW_PRIORITY INTO line_records (line_record_name, created_on) VALUES \n";
$linename = null;
for($rowIndex = 2; $rowIndex <= count($sheet['cells']); $rowIndex++)
{
	$linename = $sheet['cells'][$rowIndex][$linename_col];
	$sql .= ($sql_copy == $sql) ? "('$linename', NOW()) \n" : ", ('$linename', NOW()) \n";
}
$sql .= "ON DUPLICATE KEY UPDATE updated_on = NOW();";
mysql_query($sql) or die(mysql_error() . "\n\n$sql");

echo "\n\nDone!";