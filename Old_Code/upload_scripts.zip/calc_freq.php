<pre>
<?php


$conn = mysql_connect("lab.bcb.iastate.edu", "yhames04", "gdcb07");
mysql_select_db("sandbox_yhames04_dev");

$dataset = 1;

$sql = "
	SELECT	markers.marker_uid,
			experiments.datasets_uid,
			alleles.value,
			COUNT(alleles.value) as frequency
					
	FROM	markers,
			alleles,
			genotyping_data,
			tht_base,
			experiments
					
	WHERE	markers.marker_uid = genotyping_data.marker_uid
			AND genotyping_data.tht_base_uid = tht_base.tht_base_uid
			AND tht_base.experiment_uid = experiments.experiment_uid
			AND experiments.datasets_uid = '$dataset'
			AND alleles.genotyping_data_uid = genotyping_data.genotyping_data_uid
					
	GROUP BY markers.marker_uid, alleles.value";
$res = mysql_query($sql) or die(mysql_error());

$sql = "
	INSERT INTO allele_frequencies (marker_uid, datasets_uid, missing, aa_freq, ab_freq, bb_freq, total, monomorphic) VALUES ";

$num_entries = 0;
$row = mysql_fetch_assoc($res);
while ($row !== FALSE)
{
	$marker_uid = $row['marker_uid'];
	$datasets_uid = $row['datasets_uid'];
	
	$aafreq = 0;
	$abfreq = 0;
	$bbfreq = 0;
	$missing = 0;
	
	$frequencies_handled = 0;	
	while ($marker_uid == $row['marker_uid'])
	{
		switch ($row['value'])
		{
			case 'AA':
				$aafreq = $row['frequency'];
				break;
			case 'AB':
				$abfreq = $row['frequency'];
				break;
			case 'BB':
				$bbfreq = $row['frequency'];
				break;
			default:
				$missing = $row['frequency'];
		}
		$frequencies_handled++;
		if(!($row = mysql_fetch_assoc($res)))
			break;		
	}
	
	$total = $aafreq + $abfreq + $bbfreq + $missing;
	$monomorphic = ($frequencies_handled == 1 && $missing == 0) ? 'Y' : 'N';
	
	if ($num_entries != 0)
		$sql .= ",\n";
	
	$sql .= "('$marker_uid', '$datasets_uid', '$missing', '$aafreq', '$abfreq', '$bbfreq', '$total', '$monomorphic')";

	$num_entries++;
}

mysql_query($sql) or die(mysql_error()."\n\n$sql");
		

?>
Done!