<pre>
<?php

// begin config
$filename = "ISU_2006_UMN3_FinalReport.csv";
$snpname_col = 1;
$linename_col = 2;
$sampleindex_col = 3;
$gcscore_col = 6;
$allele1_col = 9;
$allele2_col = 10;
$theta_col = 11;
$r_col = 12;
$x_col = 13;
$y_col = 14;
$xraw_col = 15;
$yraw_col = 16;

$datasets_uid = 1;
// end config

$h = fopen($filename, "r");
for ($i=0; $i<10; $i++)
	fgets($h);


$conn = mysql_connect("lab.bcb.iastate.edu", "yhames04", "gdcb07");
mysql_select_db("sandbox_yhames04_dev");

while(!feof($h))
{
	list($snpname, $linename, $sampleindex, , , $gcscore, , , $allele1, $allele2, $theta, $r, $x, $y, $xraw, $yraw) = explode(',', trim(fgets($h)), 16);
	$allele = $allele1.$allele2;
	$allele = ($allele == '--') ? "NULL" : "'".$allele."'";
	
	
	$sql = "INSERT LOW_PRIORITY INTO genotyping_data (tht_base_uid, marker_uid, created_on)
			VALUES (
				(SELECT t.tht_base_uid FROM tht_base t, line_records l WHERE l.line_record_name = '$linename' AND l.line_record_uid = t.line_record_uid LIMIT 1),
				(SELECT marker_uid FROM markers WHERE alias = '$snpname' LIMIT 1),
				NOW());\n\n";
				
	mysql_query($sql) or die(mysql_error() . "\n\n$sql");
	
	$genotyping_data_uid = mysql_insert_id();
	
	
	$sql2 = "INSERT LOW_PRIORITY INTO marker_stat (datasets_uid,
													marker_uid,
													line_record_name,
													sample_index,
													gc_score,
													theta,
													r,
													x,
													y,
													x_raw,
													y_raw) 
			VALUES (
				'$datasets_uid',
				(SELECT marker_uid FROM markers WHERE alias = '$snpname' LIMIT 1),
				'$linename',
				'$sampleindex',
				'$gcscore',
				'$theta',
				'$r',
				'$x',
				'$y',
				'$xraw',
				'$yraw');\n\n";
	$sql2 = str_ireplace("'NaN'","NULL",$sql2);
				
	mysql_query($sql2) or die(mysql_error() . "\n\n$sql2");
				
	$sql3 = "INSERT LOW_PRIORITY INTO alleles (genotyping_data_uid, value) VALUES('$genotyping_data_uid',$allele);\n\n";
		
	mysql_query($sql3) or die(mysql_error() . "\n\n$sql3");

}

echo "\n\nDone!";
