<pre>
<?php

// begin Config
$filename = "MN06Annotations.xls";
$code = "MN06";
$datacols[0] = 2;
$datacols[1] = 6;
$datacols[2] = 10;

$year_row = 2;
$loc_row = 3;
$coords_row = 4;
$collaborator_row = 5;
$trialname_row = 6;
$plantingdate_row = 7;
$seedingrate_row = 8;
$design_row = 9;
$numreps_row = 10;
$plotsize_row = 12;
$harvestarea_row = 13;
$irrigation_row = 14;
$harvestdate_row = 15;
$otherremarks_row = 16;

$plotsize_unit = "m^2";
$harvestarea_unit = "m^2";
$seedingrate_unit = "plants/m^2";

// end Config

require_once('reader.php');
$reader = & new Spreadsheet_Excel_Reader();
$reader->setOutputEncoding('CP1251');
$reader->read($filename);
$sheet = & $reader->sheets[0];

$conn = mysql_connect("lab.bcb.iastate.edu", "yhames04", "gdcb07");
mysql_select_db("sandbox_yhames04_dev");



$sql = "";
for ($i = 0; $i < 3; $i ++)
{
	$expyear = $sheet['cells'][$year_row][$datacols[$i]];
	$exploc = $sheet['cells'][$loc_row][$datacols[$i]];
	$expcoords = $sheet['cells'][$coords_row][$datacols[$i]];
	$expcollaborator = $sheet['cells'][$collaborator_row][$datacols[$i]];
	$exptrialname = $sheet['cells'][$trialname_row][$datacols[$i]];
	$expplantingdate = $sheet['cells'][$plantingdate_row][$datacols[$i]];
	$expseedingrate = $sheet['cells'][$seedingrate_row][$datacols[$i]] . " $seedingrate_unit";
	$expdesign = $sheet['cells'][$design_row ][$datacols[$i]];
	$expnumreps = $sheet['cells'][$numreps_row][$datacols[$i]];
	$expplotsize = $sheet['cells'][$plotsize_row][$datacols[$i]] . " $plotsize_unit";
	$expharvestarea = $sheet['cells'][$harvestarea_row][$datacols[$i]] . " $harvestarea_unit";
	$expirrigation = $sheet['cells'][$irrigation_row][$datacols[$i]];
	$expharvestdate = $sheet['cells'][$harvestdate_row][$datacols[$i]];
	$expotherremarks = isset($sheet['cells'][$otherremarks_row][$datacols[$i]]) ?
						$sheet['cells'][$otherremarks_row][$datacols[$i]] :
						"";
	
	$encodeloc = array("St. Paul" => "StPaul", "Morris" => "Morris", "Crookston" => "Crookston");
	$expname = $code . $encodeloc[$exploc];

	list($explat, $explon) = split(' / ', $expcoords, 2);
	list($pdd, $pdm, $pdy) = split('/', $expplantingdate, 3);
	list($hdd, $hdm, $hdy) = split('/', $expharvestdate, 3);
	
	
	$sql = "INSERT LOW_PRIORITY INTO experiments (	experiment_name,
														experiment_year,
														collect_site_name,
														longitude,
														latitude,
														collaborator,
														trial_name,
														planting_date,
														seeding_rate,
														experiment_design,
														number_replications,
														plot_size,
														harvest_area,
														irrigation,
														harvest_date,
														other_remarks,
														created_on)
				VALUES (	'$expname',
							'$expyear',
							'$exploc',
							'$explon',
							'$explat',
							'$expcollaborator',
							'$exptrialname',
							STR_TO_DATE('$pdm/$pdd/$pdy', '%m/%d/%Y'),
							'$expseedingrate',
							'$expdesign',
							'$expnumreps',
							'$expplotsize',
							'$expharvestarea',
							'$expirrigation',
							STR_TO_DATE('$hdm/$hdd/$hdy', '%m/%d/%Y'),
							'$expotherremarks',
							NOW() );
			";
	mysql_query($sql) or die(mysql_error() . "\n\n$sql");
							
							
	
}



echo "\n\nDone!";

