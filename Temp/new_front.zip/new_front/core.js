/*
 * THT Core Javascript Functions v.1.0
 */

function toggleRow(rowNum) {

	var form = document.getElementById(rowNum);
	var i;

	disableRows(rowNum);

	if(form[1].disabled) {

		for(i=0; i<form.length; i++) {
			form[i].disabled = false;
		}

	}
	else {
		for(i=1; i<form.length; i++) {
			form[i].disabled = true;
		}
	}

	return true;
}

function disableRows(name) {

	var forms = document.forms;
	var i;
	var j;

	for(i=0; i<forms.length; i++) {

		if( (forms[i][0].type == "checkbox") && (forms[i].id != name) ) {	//this is one of our rows
				
			forms[i][0].checked = false;
			for(j=1; j<forms[i].length; j++) {
				forms[i][j].disabled = true;
			}
		}

	}

	return true;
}

function mapsetChange(value) {

	if(value != "Select" && value != "NewMapSet") {
		document.getElementById("file").disabled = false;
		showMapsetContents(value, "MapsetInfo");
	}
	else {
		document.getElementById("file").disabled = true;
		document.getElementById("MapsetInfo").innerHTML = "";
	}

	if(value == "NewMapSet") {
		document.getElementById("NewMapsetForm").style.display = "block";
	}
	else {
		document.getElementById("NewMapsetForm").style.display = "none";
	}

	document.getElementById("mapsetID").value = value;
}

function showMapsetContents(id, response) {

  	var req = getXMLHttpRequest();
	var resp = document.getElementById(response);
	var qs = "?func=showMapsetContents&id=" + id;

	if(!req) {
		resp.innerHTML = "This function requires Ajax.\nPlease update your browser.\nhttp://www.getfirefox.com";
	}

	/*
	 * Return Function
	 */
  	req.onreadystatechange = function(){
 		if(req.readyState == 4){
	    		resp.innerHTML = req.responseText;
		}
  	} 

  	req.open("GET", "includes/ajaxlib.php"+qs, true);
  	req.send(null); 
}

function getXMLHttpRequest() {

	var req;

  	try{
		// Normal Browsers
		req = new XMLHttpRequest();
  	} catch (e){
		// Internet Explorer Browsers
		try{
			req = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				req = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				alert("This function requires Ajax.\nPlease update your browser.\nhttp://www.getfirefox.com");
				return false;
			}
		}
  	}

	return req;

}

function DispSelChg (value, tablename, field) {
	if(value != "Select" && value != "New") {
		DispSelContents(value, tablename, field);
	}
	else {		
		document.getElementById(tablename+"_info").style.display = "none";
	}

	if(value == "New") {
		document.getElementById(tablename+"_div").style.display = "block";
	}
	else {
		document.getElementById(tablename+"_div").style.display = "none";
	}

	//document.getElementById(tablename+"_id").value = value;
}

function DispSelContents(value, tablename, field) {
  	var req = getXMLHttpRequest();
	var resp = document.getElementById(tablename+"_info");
	var qs = "?func=DispSelContents&tablename="+tablename+"&id=" + value+"&field="+field;
	if(!req) {
		resp.innerHTML = "This function requires Ajax.\nPlease update your browser.\nhttp://www.getfirefox.com";
	}
  	req.onreadystatechange = function(){
 		if(req.readyState == 4){
 				resp.innerHTML = req.responseText;
	    		resp.style.display="block";
		}
  	} 
  	req.open("GET", "includes/ajaxlib.php"+qs, true);
  	req.send(null); 
}

function print_r(theObj){
  if(theObj.constructor == Array ||
     theObj.constructor == Object){
    ("<ul>")
    for(var p in theObj){
      if(theObj[p].constructor == Array||
         theObj[p].constructor == Object){
("<li>["+p+"] => "+typeof(theObj)+"</li>");
        ("<ul>")
        print_r(theObj[p]);
        ("</ul>")
      } else {
("<li>["+p+"] => "+theObj[p]+"</li>");
      }
    }
    ("</ul>")
  }
}

function AddDataByAjax(tablename, field) {
	var frmeles=new Array();
	var inputfrm=document.getElementById(tablename+"_inputform");
	for (var i=0; i<inputfrm.length; i++) {
		if (inputfrm.elements[i].name.length>1) {
			frmeles.push(inputfrm.elements[i].name+"="+inputfrm.elements[i].value);
		}
	}
	var urlstr=frmeles.join('&');
	var req = getXMLHttpRequest();
	var resp = document.getElementById(tablename+"_info");
	var chgSel=document.getElementById(tablename+"_sel");
	var qs="?func=InsertByAjax&tablename="+tablename+"&"+urlstr;
	if(!req) {
		resp.innerHTML = "This function requires Ajax.\nPlease update your browser.\nhttp://www.getfirefox.com";
	}
  	req.onreadystatechange = function(){
 		if(req.readyState == 4){
 			    resp.innerHTML = req.responseText;
 				document.getElementById(tablename+"_div").style.display="none";
	    		resp.style.display="block";
	    		var idx4new;
	    		for (var i=0;i<chgSel.length; i++) {
    				if (chgSel.options[i].text=="New") {
    					idx4new=i;
    				}
 				}
 				var y=document.createElement('option');
 				var xmlDoc=req.responseXML;
 				y.text=xmlDoc.getElementsByTagName("display_text")[0].firstChild.nodeValue;
 				y.value=xmlDoc.getElementsByTagName("add_uid")[0].firstChild.nodeValue;	
				try {
    				chgSel.add(y,chgSel.options[idx4new]); // standards compliant
    				chgSel.selectedIndex=idx4new;
    				DispSelChg(xmlDoc.getElementsByTagName("add_uid")[0].firstChild.nodeValue, tablename, field); 
       			}
  				catch(e){
    				chgSel.add(y,idx4new); // IE only
    				chgSel.selectedIndex=idx4new;
    				DispSelChg(xmlDoc.getElementsByTagName("add_uid")[0].firstChild.nodeValue, tablename, field);
    			}
		}
  	} 
  	req.open("GET", "includes/ajaxlib.php"+qs, true);
  	req.send(null); 	
}

/**
 * This will validate if all the seletion tags have values
 */
 function validate_foreign_sels () {
 	var selections=document.getElementsByTagName("select");
 	var flag=0;
 	var selstr="";
 	for (var i=0; i<selections.length; i++) {
 		var idx=selections[i].selectedIndex;
 		if (selections[i].options[idx].value=="Select" || selections[i].options[idx].value=="New") {
 			flag++;
 		}
 		else {
 			selstr+=selections[i].id+","+selections[i].options[idx].value+":";
 		}
 	}
 	if (flag==0) {
 		document.getElementById("foreign_references").style.display="none";
 		document.getElementById("processing_tables").style.display="block";
 		InsertTableByAjax(selstr);
 	}
 	else {
 		alert("Not all the foreign tables have been taken care of!");
 	}
 }
 
 /** 
  * This will insert the table information into the database by calling InsertTableByAjax in  ajaxlib.php
  */
 function InsertTableByAjax (selstr) {
   	var req = getXMLHttpRequest();
	var resp = document.getElementById("processing_tables");
	var qs = "?func=InsertTableByAjax&selstr="+selstr;
	if(!req) {
		resp.innerHTML = "This function requires Ajax.\nPlease update your browser.\nhttp://www.getfirefox.com";
	}
  	req.onreadystatechange = function(){
 		if(req.readyState == 4){
 				resp.innerHTML = req.responseText;
	    		resp.style.display="block";
		}
  	} 
  	req.open("GET", "includes/ajaxlib.php"+qs, true);
  	req.send(null); 
}